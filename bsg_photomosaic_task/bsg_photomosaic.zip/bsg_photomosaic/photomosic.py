
import numpy as np
import argparse

import cv2
import glob

image_paths = glob.glob('C:/Users/LENOVO/Desktop/Vortexx/Vortex_submission/bsg_photomosaic/Resources/*.png')
images = []

for image in image_paths:
    img = cv2.imread(image)
    imgResized= cv2.resize(img,(200,200))
    images.append(imgResized)
    cv2.imshow("Image", imgResized)
    cv2.waitKey(0)


#imageStitcher = cv2.Stitcher_create()

#error, stitched_img = imageStitcher.stitch(images)


im_h1 = cv2.hconcat([images[0], images[1],images[2],images[3]])
im_h2 = cv2.hconcat([images[4], images[5],images[6],images[7]])

crop = im_h1[0:150, 0:800]
im_v = cv2.vconcat([crop, im_h2])
# show the output image
cv2.imwrite("n.png",im_v)
cv2.imshow('sea_image.jpg', im_v)


cv2.waitKey(0)